ARCHIVE_HOME=/opt/regal
SERVER=localhost
ARCHIVE_USER=jan
ARCHIVE_PASSWORD=schnasse
EMAIL=schnasse@hbz-nrw.de
APACHE_CONF=/etc/apache2/apache2.conf

TOMCAT_PORT=8080
ELASTICSEARCH_PORT=9200


# Only needed when you want to mirror from a supported system (edoweb|ellinet|dipp)
PREFIX=edoweb
DOWNLOAD=http://klio.hbz-nrw.de:1801
OAI=http://klio.hbz-nrw.de:1801/edowebOAI
SET=edoweb-oai_dc-all


